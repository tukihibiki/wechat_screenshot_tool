import os
import cv2
import pytesseract
from PIL import Image
import numpy as np
import difflib
from tqdm import tqdm

# 配置Tesseract路径（根据实际安装路径修改）
# pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

def calculate_similarity(text1, text2):
    """计算两段文本的相似度"""
    seq = difflib.SequenceMatcher(None, text1, text2)
    return seq.ratio()

def extract_text_from_image(img):
    """从图像中提取文本"""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    text = pytesseract.image_to_string(gray, lang='chi_sim+eng')
    return text.strip()

def save_screenshot(frame, count, save_dir):
    """保存截图"""
    filename = os.path.join(save_dir, f"screenshot_{count:04d}.png")
    cv2.imwrite(filename, frame)
    return filename

def process_video(video_path, save_dir, min_interval=15, max_interval=200):
    """处理视频文件"""
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"无法打开视频文件: {video_path}")
        return
    
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    print(f"开始处理视频: {video_path}")
    print(f"总帧数: {total_frames}, FPS: {fps}\n\n")
    
    # 创建进度条
    pbar = tqdm(total=total_frames, desc="处理进度", unit="帧")

    count = 0
    last_text = ""
    last_screenshot_count = 0
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
            
        # 每10帧处理一次
        if count % 10 != 0:
            count += 1
            cap.set(cv2.CAP_PROP_POS_FRAMES, count)  # 直接跳到下一处理帧
            continue
            
        # 更新进度条
        pbar.update(10)  # 每次处理10帧
        pbar.set_postfix_str(f"当前帧: {count}/{total_frames}\n\n")
            
        count += 1
        
        # 动态调整检测间隔
        if count - last_screenshot_count < min_interval:
            continue
            
        # 提取当前帧文本
        current_text = extract_text_from_image(frame)
        if not current_text:
            continue
            
        # 检查是否需要截图
        needs_screenshot = False
        if not last_text:  # 第一张截图
            needs_screenshot = True
        else:
            # 计算文本相似度
            similarity = calculate_similarity(last_text, current_text)
            if similarity < 0.25:  # 相似度低于25%才截图
                needs_screenshot = True
            # 强制最大间隔截图
            elif count - last_screenshot_count >= max_interval:
                needs_screenshot = True
                
        if needs_screenshot:
            save_screenshot(frame, count, save_dir)
            last_text = current_text
            last_screenshot_count = count
        
    cap.release()
    pbar.close()
    print(f"\n\n视频处理完成，保存截图到: {save_dir}")

if __name__ == "__main__":
    # 创建输出目录
    os.makedirs("save", exist_ok=True)
    
    # 处理videos目录下的所有视频
    video_dir = "videos"
    for filename in os.listdir(video_dir):
        if filename.lower().endswith(('.mp4', '.avi', '.mov')):
            video_path = os.path.join(video_dir, filename)
            process_video(video_path, "save")
